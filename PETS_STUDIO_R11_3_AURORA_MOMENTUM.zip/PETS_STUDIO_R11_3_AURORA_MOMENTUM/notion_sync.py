"""Small, explicit Notion API bridge for the local PETS Studio app.

The token is held by the process only. The database URL and page mapping are
safe operational metadata; article text stays local unless the user presses a
sync action.
"""
import json, urllib.error, urllib.request
from datetime import datetime
from urllib.parse import urlparse
from core import Problem, empty_article, fingerprint, validate_article

API='https://api.notion.com/v1'
NOTION_VERSION='2022-06-28'
RUBRICS={'HOME':'Дом и привычки','BEHAVIOR':'Поведение','BEHAVIOUR':'Поведение','WALK':'Прогулки','CARE':'Уход и возраст','HEALTH':'Уход и возраст','CHOICE':'Выбор без рекламы','STORY':'Истории и опыт'}
RUBRICS_REVERSE={v:k for k,v in RUBRICS.items()}


def database_id(value):
    value=str(value or '').strip()
    if not value: raise Problem('Укажите ссылку на базу Notion.')
    raw=urlparse(value).path.rstrip('/').split('/')[-1]
    raw=raw.split('-')[-1] if raw.count('-')>0 and len(raw.replace('-',''))==32 else raw.replace('-','')
    if len(raw)!=32 or any(c not in '0123456789abcdefABCDEF' for c in raw):
        raise Problem('Не удалось определить ID базы Notion из ссылки.')
    return raw


def _api(token, method, path, payload=None):
    if not isinstance(token,str) or not token.strip(): raise Problem('Сначала подключите Notion API token.')
    body=None if payload is None else json.dumps(payload,ensure_ascii=False).encode()
    req=urllib.request.Request(API+path,data=body,method=method,headers={'Authorization':'Bearer '+token.strip(),'Notion-Version':NOTION_VERSION,'Content-Type':'application/json','Accept':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=30) as r: raw=r.read()
    except urllib.error.HTTPError as e:
        try: detail=json.loads(e.read().decode('utf-8','replace')).get('message','')
        except Exception: detail=''
        raise Problem('Notion API: '+(detail or f'HTTP {e.code}'),502)
    except (urllib.error.URLError,TimeoutError) as e:
        raise Problem('Не удалось связаться с Notion API: '+str(e.reason if hasattr(e,'reason') else e),502)
    try:return json.loads(raw.decode('utf-8'))
    except (ValueError,UnicodeDecodeError):raise Problem('Notion API вернул некорректный ответ.',502)


def _plain(prop):
    if not isinstance(prop,dict): return ''
    typ=prop.get('type')
    if typ in ('title','rich_text'):
        return ''.join(x.get('plain_text',x.get('text',{}).get('content','')) for x in prop.get(typ,[]))
    if typ=='select': return (prop.get('select') or {}).get('name','')
    if typ=='status': return (prop.get('status') or {}).get('name','')
    if typ=='url': return prop.get('url') or ''
    if typ=='date': return (prop.get('date') or {}).get('start','')
    if typ=='checkbox': return bool(prop.get('checkbox'))
    return ''


def _text(value):
    value=str(value or '')
    return {'type':'rich_text','rich_text':[{'type':'text','text':{'content':value[:2000]}}]} if value else {'type':'rich_text','rich_text':[]}


def _title(value):
    value=str(value or '')
    return {'title':[{'type':'text','text':{'content':value[:2000]}}]} if value else {'title':[]}


def _date(value):
    value=str(value or '').strip()
    if not value:return {'date':None}
    return {'date':{'start':value.replace('T','T',1)}}


def article_properties(a,pets_id=None):
    status='Опубликовано' if a.get('published_url') else 'Готово' if a.get('gates',{}).get('layout') and all(a.get('gates',{}).get(k) for k in ('facts','safety','rights','originality','promise','logic','layout')) else 'В работе' if a.get('body','').strip() else 'Черновик'
    rubric=RUBRICS.get(a.get('brief',{}).get('rubric','HOME'),'Дом и привычки')
    return {
      'Название':_title(a.get('title')),
      'PETS ID':_text(pets_id or a.get('notion',{}).get('page_id') or ''),
      'Статус':{'status':{'name':status}},
      'Формат':{'select':{'name':a.get('format') or 'Разбор ситуации'}},
      'Рубрика':{'select':{'name':rubric}},
      'Тема':_text(a.get('topic')),'Аудитория':_text(a.get('audience')),'Подача':_text(a.get('tone')),
      'TL;DR':_text(a.get('brief',{}).get('promise') or a.get('topic')),
      'Плановая дата':_date(a.get('plan_at')),
      'URL публикации':{'url':a.get('published_url') or None},
      'Синхронизировано':{'checkbox':True}
    }


def _blocks(text):
    blocks=[]
    for paragraph in str(text or '').split('\n\n'):
        paragraph=paragraph.strip()
        if not paragraph:continue
        while paragraph:
            chunk=paragraph[:1900]; paragraph=paragraph[1900:]
            blocks.append({'object':'block','type':'paragraph','paragraph':{'rich_text':[{'type':'text','text':{'content':chunk}}]}})
    return blocks[:100]


def _read_blocks(token,page_id):
    out=[];cursor=''
    while True:
        path=f'/blocks/{page_id}/children?page_size=100'+(('&start_cursor='+cursor) if cursor else '')
        data=_api(token,'GET',path)
        for block in data.get('results',[]):
            typ=block.get('type','');payload=block.get(typ,{})
            if typ in ('paragraph','heading_1','heading_2','heading_3','bulleted_list_item','numbered_list_item','quote'):
                txt=''.join(x.get('plain_text',x.get('text',{}).get('content','')) for x in payload.get('rich_text',[]))
                if txt:out.append(txt)
        if not data.get('has_more'):break
        cursor=data.get('next_cursor','')
        if not cursor:break
    return '\n\n'.join(out)


def query(token,dbid):
    rows=[];cursor=None
    while True:
        payload={'page_size':100}
        if cursor:payload['start_cursor']=cursor
        data=_api(token,'POST',f'/databases/{dbid}/query',payload)
        rows.extend(data.get('results',[]))
        if not data.get('has_more'):break
        cursor=data.get('next_cursor')
        if not cursor:break
    return rows


def page_to_article(token,page):
    props=page.get('properties',{})
    a=empty_article()
    a['title']=_plain(props.get('Название')) or 'Материал из Notion'
    a['topic']=_plain(props.get('Тема'))
    a['audience']=_plain(props.get('Аудитория')) or a['audience']
    a['tone']=_plain(props.get('Подача')) or a['tone']
    a['format']=_plain(props.get('Формат')) or a['format']
    a['published_url']=_plain(props.get('URL публикации'))
    plan=_plain(props.get('Плановая дата'))
    a['plan_at']=plan[:16] if plan else ''
    rubric=RUBRICS_REVERSE.get(_plain(props.get('Рубрика')),'HOME')
    a['brief']['rubric']=rubric;a['brief']['promise']=_plain(props.get('TL;DR'))
    a['body']=_read_blocks(token,page['id'])
    a['notion']={'page_id':page['id'],'last_edited_time':page.get('last_edited_time',''),'last_synced_fingerprint':''}
    return validate_article(a)


def _create_page(token,dbid,a):
    payload={'parent':{'database_id':dbid},'properties':article_properties(a)}
    blocks=_blocks(a.get('body'))
    if blocks:payload['children']=blocks
    created=_api(token,'POST','/pages',payload)
    _api(token,'PATCH',f"/pages/{created['id']}",{'properties':article_properties(a,created['id'])})
    return _api(token,'GET',f"/pages/{created['id']}")


def _replace_body(token,page_id,text):
    children=_api(token,'GET',f'/blocks/{page_id}/children?page_size=100').get('results',[])
    for child in children:
        _api(token,'DELETE',f"/blocks/{child['id']}")
    blocks=_blocks(text)
    if blocks:_api(token,'PATCH',f'/blocks/{page_id}/children',{'children':blocks})


def _update_page(token,page_id,a):
    page=_api(token,'PATCH',f'/pages/{page_id}',{'properties':article_properties(a,page_id)})
    _replace_body(token,page_id,a.get('body',''))
    return _api(token,'GET',f'/pages/{page_id}')


def _index(pages):
    by_id={};by_pet={}
    for p in pages:
        by_id[p.get('id')]=p
        pet=_plain(p.get('properties',{}).get('PETS ID'))
        if pet:by_pet[pet]=p
    return by_id,by_pet


def sync(store,token,database_url,mode):
    dbid=database_id(database_url);pages=query(token,dbid);by_page,by_pet=_index(pages)
    local=store.list_articles();local_full={x['id']:store.get(x['id']) for x in local};result={'mode':mode,'pulled':0,'pushed':0,'created':0,'unchanged':0,'conflicts':[],'errors':[]}
    seen=set()
    def pull_page(page,existing=None):
        data=page_to_article(token,page);data['notion']['last_synced_fingerprint']=fingerprint(data)
        if existing:
            store.save(existing['id'],data,existing['revision']);store.set_notion_meta(existing['id'],data['notion']);result['pulled']+=1
        else:
            item=store.save(None,data)
            _api(token,'PATCH',f"/pages/{page['id']}",{'properties':article_properties(data,page['id'])})
            refreshed=_api(token,'GET',f"/pages/{page['id']}")
            store.set_notion_meta(item['id'],{'page_id':page['id'],'last_edited_time':refreshed.get('last_edited_time',''),'last_synced_fingerprint':fingerprint(data)})
            result['created']+=1
    for page in pages:
        pet=_plain(page.get('properties',{}).get('PETS ID'));existing=None
        if pet and pet in local_full:existing=local_full[pet]
        elif page.get('id'):
            existing=next((x for x in local_full.values() if x['data'].get('notion',{}).get('page_id')==page['id']),None)
        if existing:
            seen.add(existing['id']);n=existing['data'].get('notion',{});fp=fingerprint(existing['data']);baseline=n.get('last_synced_fingerprint','');remote_changed=bool(baseline and page.get('last_edited_time')!=n.get('last_edited_time'));local_changed=bool(baseline and fp!=baseline)
            if mode=='pull' and (remote_changed or not baseline):pull_page(page,existing)
            elif mode=='push' and local_changed:
                if remote_changed:result['conflicts'].append(existing['id'])
                else:
                    updated=_update_page(token,page['id'],existing['data']);store.set_notion_meta(existing['id'],{'page_id':page['id'],'last_edited_time':updated.get('last_edited_time',''),'last_synced_fingerprint':fingerprint(existing['data'])});result['pushed']+=1
            elif mode=='sync':
                if remote_changed and local_changed:result['conflicts'].append(existing['id'])
                elif remote_changed or not baseline:pull_page(page,existing)
                elif local_changed:
                    updated=_update_page(token,page['id'],existing['data']);store.set_notion_meta(existing['id'],{'page_id':page['id'],'last_edited_time':updated.get('last_edited_time',''),'last_synced_fingerprint':fingerprint(existing['data'])});result['pushed']+=1
                else:result['unchanged']+=1
        elif mode in ('pull','sync'):
            pull_page(page)
    if mode in ('push','sync'):
        for item in local_full.values():
            if item['id'] in seen:continue
            a=item['data'];n=a.get('notion',{});page=by_page.get(n.get('page_id')) or by_pet.get(n.get('page_id',''))
            if page:
                updated=_update_page(token,page['id'],a);store.set_notion_meta(item['id'],{'page_id':page['id'],'last_edited_time':updated.get('last_edited_time',''),'last_synced_fingerprint':fingerprint(a)});result['pushed']+=1
            else:
                created=_create_page(token,dbid,a);store.set_notion_meta(item['id'],{'page_id':created['id'],'last_edited_time':created.get('last_edited_time',''),'last_synced_fingerprint':fingerprint(a)});result['pushed']+=1
    result['message']=f"Импортировано: {result['pulled']}; отправлено: {result['pushed']}; новых: {result['created']}; конфликтов: {len(result['conflicts'])}."
    return result


def test(token,database_url):
    dbid=database_id(database_url);data=_api(token,'GET',f'/databases/{dbid}')
    title=''.join(x.get('plain_text','') for x in data.get('title',[])) or 'База Notion'
    return {'ok':True,'database_id':dbid,'title':title,'message':'Подключение к Notion подтверждено. Доступ к базе есть.'}
