"""Optional Copyleaks adapter. Credentials stay only in the server process."""
import hashlib, json, math, urllib.request, urllib.error, uuid
SCOPE='Оценка внешнего сервиса, не доказательство авторства. Возможны ложные срабатывания и пропуски. Не используется как допуск Дзена и не заменяет редактуру.'
def config(value):
 if not isinstance(value,dict):raise ValueError('Некорректные настройки детектора.')
 if not isinstance(value.get('email',''),str) or not isinstance(value.get('key',''),str):raise ValueError('Некорректный email или ключ.')
 email=value.get('email','').strip();key=value.get('key','').strip()
 if not isinstance(email,str) or not isinstance(key,str) or not 3<len(email)<=254 or '@' not in email or any(c.isspace() for c in email) or not 1<=len(key)<=2000 or not key.isascii() or any(c.isspace() for c in key):raise ValueError('Нужны корректные email и отдельный API-ключ Copyleaks.')
 return {'email':email,'key':key,'consent':value.get('consent') is True}
def post(url,payload,headers=None):
 req=urllib.request.Request(url,json.dumps(payload).encode(),{'Content-Type':'application/json','Accept':'application/json',**(headers or {})},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=100) as r:data=json.loads(r.read(3_000_000))
 except urllib.error.HTTPError as e:raise ValueError(f'Copyleaks: HTTP {e.code}. Проверьте доступ к AI Detection API, ключ и баланс. Автоматического повтора нет.')
 except (OSError,ValueError):raise ValueError('Copyleaks: сеть, тайм-аут или некорректный ответ. Списание возможно; автоматического повтора нет.')
 if not isinstance(data,dict):raise ValueError('Copyleaks вернул неподдерживаемый ответ.')
 return data

def check(text,credentials,sandbox=False):
 if not isinstance(text,str) or not 255<=len(text)<=100000:raise ValueError('Внешний детектор принимает 255–100 000 символов. Текст не отправлен.')
 if not credentials or not credentials.get('consent'):raise ValueError('Подключите отдельный ключ Copyleaks и подтвердите передачу текста. Текст не отправлен.')
 if not isinstance(sandbox,bool):raise ValueError('Некорректный режим детектора.')
 auth = post("https://" + "id.copyleaks.com/v3/account/login/api", dict(email=credentials["email"], key=credentials["key"]))
 token=auth.get('access_token')
 if not isinstance(token,str) or not token or not token.isascii() or any(c.isspace() for c in token):raise ValueError('Copyleaks не вернул корректный токен. Проверка не отправлена.')
 raw=post('https://api.copyleaks.com/v2/writer-detector/'+str(uuid.uuid4())+'/check',{'text':text,'sandbox':sandbox,'language':'ru','explain':False,'sensitivity':2},{'Authorization':'Bearer '+token})
 summary=raw.get('summary',{});clean={}
 if not isinstance(summary,dict):raise ValueError('Неподдерживаемый итог Copyleaks.')
 for k in ('human','ai'):
  n=summary.get(k)
  if isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n) or not 0<=n<=1:raise ValueError('Неподдерживаемая шкала ответа Copyleaks.')
  clean[k]=n
 return {'provider':'Copyleaks','summary':clean,'model_version':str(raw.get('modelVersion','не указан'))[:100],'sandbox':sandbox,'content_hash':hashlib.sha256(text.encode()).hexdigest(),'scope':SCOPE,'status':'SANDBOX — тест интеграции, не оценка текста' if sandbox else 'Ответ внешнего AI-детектора'}
