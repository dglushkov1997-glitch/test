import copy, json, sqlite3, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import core, editorial
import test_service
class EditorialTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.s=core.Store(Path(self.tmp.name)/'v2.db');self.a=core.empty_article()
 def tearDown(self):self.tmp.cleanup()
 def test_brief_defaults(self):self.assertEqual(self.a['brief']['demand_status'],'hypothesis')
 def test_old_card_normalized(self):a=copy.deepcopy(self.a);del a['brief'];del a['measurements'];self.assertEqual(core.validate_article(a)['measurements'],[])
 def test_bad_brief(self):self.assertRaises(core.Problem,core.validate_article,{**self.a,'brief':{'rubric':'fake'}})
 def test_false_demand(self):self.a['brief']['demand_status']='observed';self.assertTrue(editorial.diagnostics(self.a)['notes'])
 def test_new_author_gate(self):self.assertTrue(any('вклад' in x for x in core.qc(self.a)['release_pending']))
 def test_metrics_null(self):r=editorial.measurements([{'impressions':None,'opens':None}]);self.assertIsNone(editorial.rates(r[0])['ctr'])
 def test_metrics_zero(self):r=editorial.measurements([{'impressions':0,'opens':0}]);self.assertIsNone(editorial.rates(r[0])['ctr'])
 def test_metrics_rate(self):r=editorial.measurements([{'impressions':2000,'opens':100,'completions':45}]);self.assertEqual(editorial.rates(r[0]),{'ctr':5.0,'completion_rate':45.0})
 def test_wrong_denominator(self):self.assertRaises(ValueError,editorial.measurements,[{'impressions':10,'opens':20}])
 def test_bad_completions(self):self.assertRaises(ValueError,editorial.measurements,[{'opens':10,'completions':20}])
 def test_negative_metric(self):self.assertRaises(ValueError,editorial.measurements,[{'opens':-1}])
 def test_bool_metric(self):self.assertRaises(ValueError,editorial.measurements,[{'opens':True}])
 def test_fraction_metric(self):self.assertRaises(ValueError,editorial.measurements,[{'opens':3.5}])
 def test_future_metric(self):self.assertRaises(ValueError,editorial.measurements,[{'recorded_on':'2099-01-01'}])
 def test_history_preserves_seed(self):a=self.s.get(self.s.list_articles()[0]['id']);a['data']['title']='Edited';self.s.save(a['id'],a['data'],a['revision']);self.assertGreaterEqual(len(self.s.history(a['id'])),2)
 def test_history_bound(self):
  a=self.s.save(None,self.a)
  for i in range(45):a['data']['title']=str(i);a=self.s.save(a['id'],a['data'],a['revision'])
  self.assertEqual(len(self.s.history(a['id'])),40)
 def test_version_ownership(self):a=self.s.save(None,self.a);b=self.s.save(None,self.a);self.assertRaises(core.Problem,self.s.version,b['id'],self.s.history(a['id'])[0]['id'])
 def test_restore_resets_gates(self):
  a=self.s.save(None,self.a);v=self.s.history(a['id'])[0]['id'];a['data']['body']='changed';a=self.s.save(a['id'],a['data'],a['revision']);z=self.s.restore_version(a['id'],v,a['revision']);self.assertEqual(z['data']['body'],'');self.assertFalse(any(z['data']['gates'].values()))
 def test_restore_keeps_outcomes(self):
  a=self.s.save(None,self.a);v=self.s.history(a['id'])[0]['id'];a['data']['measurements']=[{'impressions':100,'opens':10}];a['data']['published_url']='https://dzen.ru/a/test';a=self.s.save(a['id'],a['data'],a['revision']);z=self.s.restore_version(a['id'],v,a['revision']);self.assertEqual(z['data']['measurements'][0]['opens'],10);self.assertTrue(z['data']['published_url'])
 def test_restore_conflict(self):a=self.s.save(None,self.a);v=self.s.history(a['id'])[0]['id'];self.assertRaises(core.Problem,self.s.restore_version,a['id'],v,0)
 def test_exact_archive_match(self):
  self.a['body']='Это конкретный достаточно длинный абзац про собаку и спокойное место в обычной квартире. '*4;a=self.s.save(None,self.a);r=self.s.archive_check(None,self.a);self.assertEqual(r['matches'][0]['body_overlap'],100)
 def test_archive_excludes_self(self):a=self.s.save(None,self.a);self.assertFalse(self.s.archive_check(a['id'],self.a)['matches'])
 def test_learning_not_content_hash(self):
  h=core.fingerprint(self.a);self.a['brief']['learning']='Новый результат';self.a['brief']['experiment']='Следующий тест';self.assertEqual(h,core.fingerprint(self.a))
 def test_empty_similarity(self):self.assertEqual(editorial.similarity({},[{'id':'x','data':{}}])['matches'],[])
 def test_backup_history_roundtrip(self):a=self.s.save(None,self.a);b=self.s.backup();self.s.restore(b);self.assertGreater(len(self.s.backup()['history']),len(b['history']))
 def test_invalid_history_atomic(self):
  b=self.s.backup();b['history']=[{'article_id':'missing','data':{}}];n=len(self.s.list_articles());self.assertRaises(core.Problem,self.s.restore,b);self.assertEqual(n,len(self.s.list_articles()))
 def test_migration_backup(self):
  path=Path(self.tmp.name)/'legacy.db';a=copy.deepcopy(self.a);del a['brief'];del a['measurements']
  with sqlite3.connect(path) as c:
   c.execute('CREATE TABLE articles(id TEXT PRIMARY KEY,data TEXT,revision INTEGER,created TEXT,updated TEXT,approval TEXT)');c.execute('INSERT INTO articles VALUES(?,?,?,?,?,?)',('legacy',json.dumps(a),1,core.now(),core.now(),'old-approval'))
  s=core.Store(path);self.assertIsNone(s.get('legacy')['approval']);self.assertTrue(list(path.parent.glob('studio.pre-v2.*.sqlite3')));self.assertEqual(len(s.history('legacy')),1)
  before=len(list(path.parent.glob('studio.pre-v2.*.sqlite3')));core.Store(path);self.assertEqual(before,len(list(path.parent.glob('studio.pre-v2.*.sqlite3'))))
class V2HTTPTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):test_service.HTTPTests.setUpClass.__func__(cls)
 @classmethod
 def tearDownClass(cls):test_service.HTTPTests.tearDownClass.__func__(cls)
 req=test_service.HTTPTests.req
 def test_history_route(self):
  a=self.server.store.list_articles()[0]
  with self.req('/api/history?id='+a['id']) as r:self.assertIsInstance(json.load(r),list)
 def test_hold_before_provider(self):
  with patch('app.call_provider') as request:
   with self.req('/api/generate',{'task':'article','mode':'ai','data':core.empty_article()}) as r:self.assertTrue(json.load(r)['result']['hold'])
   request.assert_not_called()
 def test_image_served(self):
  with self.req('/hero.jpg') as r:self.assertIn('image/jpeg',r.headers['Content-Type']);self.assertTrue(r.read().startswith(b'\xff\xd8'))
