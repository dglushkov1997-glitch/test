import io
import json
import re
import tempfile
import unittest
import zipfile
from pathlib import Path

from app import project_context_zip
from core import AI_CONTRACT_VERSION, PROJECT_CONTEXT_FORMAT, PROJECT_VERSION, Store


class PortableProjectTests(unittest.TestCase):
    def test_context_has_stable_manifest_and_no_credentials(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "pets.sqlite3")
            context = store.portable_context()
            self.assertEqual(context["format"], PROJECT_CONTEXT_FORMAT)
            self.assertEqual(context["project_version"], PROJECT_VERSION)
            self.assertEqual(context["ai_contract_version"], AI_CONTRACT_VERSION)
            self.assertRegex(context["context_manifest"]["sha256"], r"^[0-9a-f]{64}$")
            self.assertNotIn("api_key", json.dumps(context).lower())

    def test_package_is_self_contained_and_credential_free(self):
        with tempfile.TemporaryDirectory() as tmp:
            blob = project_context_zip(Store(Path(tmp) / "pets.sqlite3"))
            with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                names = set(archive.namelist())
                required = {
                    "PETS_PROJECT_CONTEXT.md",
                    "PETS_PROJECT_CONTEXT.json",
                    "PETS_PROMPT_MANIFEST.json",
                    "PETS_GOLDEN_TESTS.json",
                    "PETS_ACTIVE_CONTEXT.md",
                    "PETS_STUDIO_BACKUP.json",
                    "PETS_CONTEXT_SHA256.txt",
                    "PETS_MIGRATION.md",
                    "PETS_CHANGELOG.md",
                }
                self.assertTrue(required <= names)
                self.assertFalse(any("key" in n.lower() or "token" in n.lower() for n in names))
                manifest = json.loads(archive.read("PETS_PROMPT_MANIFEST.json"))
                self.assertRegex(manifest["context_manifest"]["sha256"], r"^[0-9a-f]{64}$")


if __name__ == "__main__":
    unittest.main()