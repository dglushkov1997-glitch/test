import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from app import AppServer, full_backup_zip, health_report
from core import Store


class HardeningTests(unittest.TestCase):
    def test_schema_and_assets_are_explicit(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'pets.sqlite3')
            self.assertEqual(store.schema_version(), 3)
            (Path(tmp) / 'images').mkdir()
            (Path(tmp) / 'images' / 'demo.jpg').write_bytes(b'asset')
            inventory = store.asset_inventory()
            self.assertEqual(inventory['count'], 1)
            self.assertEqual(inventory['bytes'], 5)

    def test_full_backup_contains_database_and_visual_assets_without_secrets(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = Store(root / 'pets.sqlite3')
            (root / 'images').mkdir()
            (root / 'images' / 'demo.jpg').write_bytes(b'asset')
            blob = full_backup_zip(store)
            with zipfile.ZipFile(io.BytesIO(blob)) as archive:
                names = set(archive.namelist())
                self.assertIn('data/studio.sqlite3', names)
                self.assertIn('data/images/demo.jpg', names)
                manifest = json.loads(archive.read('PETS_FULL_BACKUP_MANIFEST.json'))
                self.assertFalse(manifest['credentials_included'])
                self.assertEqual(manifest['asset_count'], 1)
                self.assertNotIn(b'api_key', blob.lower())

    def test_health_is_local_and_does_not_require_provider(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / 'pets.sqlite3')
            server = AppServer(('127.0.0.1', 0), store)
            try:
                report = health_report(server, store)
                self.assertEqual(report['status'], 'PASS')
                self.assertEqual(report['paid_request'], False)
                self.assertEqual(report['external_status'], 'NOT_CONFIGURED')
                self.assertTrue(all(x['status'] == 'PASS' for x in report['checks']))
            finally:
                server.server_close()


if __name__ == '__main__':
    unittest.main()
