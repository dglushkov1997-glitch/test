# PETS Studio — R11.3 Hardened + Aurora Raycast

Полный обновлённый архив проекта. Данные и функциональность R11.3 сохранены; изменён только визуальный слой и необходимая раздача нового CSS-файла.

## Запуск на Linux / macOS

```bash
python3 app.py --no-browser
```

Для доступа с телефона в одной Wi-Fi сети:

```bash
python3 app.py --lan
```

Windows: используйте `START_WINDOWS.bat` или `START_WINDOWS_LAN.bat`.

## Что открывать

После запуска откройте адрес, который покажет приложение. Основной экран — «Обзор», рабочий поток — «Редактор».

## Обновление Aurora Raycast

Визуальная тема подключается в `web/index.html` через:

- `web/aurora-raycast.css`

Исходные данные проекта находятся в `data/studio.sqlite3`. До дальнейших изменений сохраняйте копию архива целиком.

## Проверка

```bash
python3 -m unittest discover -s tests -v
```

Текущий результат: 134 теста пройдено.

## Архив до обновления

`backups/PETS_STUDIO_R11_3_HARDENED_ORIGINAL.zip`

## Превью

- `previews/PETS_STUDIO_AURORA_DESKTOP.png`
- `previews/PETS_STUDIO_AURORA_MOBILE.png`
